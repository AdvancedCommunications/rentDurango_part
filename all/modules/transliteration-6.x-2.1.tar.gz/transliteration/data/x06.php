<?php
// $Id: x06.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ';', NULL, NULL, NULL, '?',
    NULL, '', 'a', '\'', 'w\'', '', 'y\'', '', 'b', '@', 't', 'th', 'j', 'H', 'kh', 'd',
    'dh', 'r', 'z', 's', 'sh', 'S', 'D', 'T', 'Z', '`', 'G', NULL, NULL, NULL, NULL, NULL,
    '', 'f', 'q', 'k', 'l', 'm', 'n', 'h', 'w', '~', 'y', 'an', 'un', 'in', 'a', 'u',
    'i', 'W', '', '', '\'', '\'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '%', '.', ',', '*', NULL, NULL,
    '', '\'', '\'', '\'', '', '\'', '\'w', '\'u', '\'y', 'tt', 'tth', 'b', 't', 'T', 'p', 'th',
    'bh', '\'h', 'H', 'ny', 'dy', 'H', 'ch', 'cch', 'dd', 'D', 'D', 'Dt', 'dh', 'ddh', 'd', 'D',
    'D', 'rr', 'R', 'R', 'R', 'R', 'R', 'R', 'j', 'R', 'S', 'S', 'S', 'S', 'S', 'T',
    'GH', 'F', 'F', 'F', 'v', 'f', 'ph', 'Q', 'Q', 'kh', 'k', 'K', 'K', 'ng', 'K', 'g',
    'G', 'N', 'G', 'G', 'G', 'L', 'L', 'L', 'L', 'N', 'N', 'N', 'N', 'N', 'h', 'Ch',
    'hy', 'h', 'H', '@', 'W', 'oe', 'oe', 'u', 'yu', 'yu', 'W', 'v', 'y', 'Y', 'Y', 'W',
    '', '', 'y', 'y\'', '.', 'ae', '', '', '', '', '', '', '', '@', '#', '',
    '', '', '', '', '', '', '', '', '', '^', '', '', '', '', NULL, NULL,
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'Sh', 'D', 'Gh', '&', '+m'),
);
