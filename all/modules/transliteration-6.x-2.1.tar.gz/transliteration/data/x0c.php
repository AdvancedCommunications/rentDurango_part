<?php
// $Id: x0c.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, 'N', 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', NULL, 'e', 'ee',
    'ai', NULL, 'o', 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
    'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bh', 'm', 'y',
    'r', 'rr', 'l', 'll', NULL, 'v', 'sh', 'ss', 's', 'h', NULL, NULL, NULL, NULL, 'aa', 'i',
    'ii', 'u', 'uu', 'R', 'RR', NULL, 'e', 'ee', 'ai', NULL, 'o', 'oo', 'au', '', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, '+', '+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    'RR', 'LL', NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', NULL, 'e', 'ee',
    'ai', NULL, 'o', 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
    'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bh', 'm', 'y',
    'r', 'rr', 'l', 'll', NULL, 'v', 'sh', 'ss', 's', 'h', NULL, NULL, NULL, NULL, 'aa', 'i',
    'ii', 'u', 'uu', 'R', 'RR', NULL, 'e', 'ee', 'ai', NULL, 'o', 'oo', 'au', '', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, '+', '+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'lll', NULL,
    'RR', 'LL', NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
