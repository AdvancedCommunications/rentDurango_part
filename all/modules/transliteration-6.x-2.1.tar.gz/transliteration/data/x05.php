<?php
// $Id: x05.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, 'A', 'B', 'G', 'D', 'E', 'Z', 'E', 'E', 'T`', 'Zh', 'I', 'L', 'Kh', 'Ts', 'K',
    'H', 'Dz', 'Gh', 'Ch', 'M', 'Y', 'N', 'Sh', 'O', 'Ch`', 'P', 'J', 'Rh', 'S', 'V', 'T',
    'R', 'Ts`', 'W', 'P`', 'K`', 'O', 'F', NULL, NULL, '<', '\'', '/', '!', ',', '?', '.',
    NULL, 'a', 'b', 'g', 'd', 'e', 'z', 'e', 'e', 't`', 'zh', 'i', 'l', 'kh', 'ts', 'k',
    'h', 'dz', 'gh', 'ch', 'm', 'y', 'n', 'sh', 'o', 'ch`', 'p', 'j', 'rh', 's', 'v', 't',
    'r', 'ts`', 'w', 'p`', 'k`', 'o', 'f', 'ew', NULL, '.', '-', NULL, NULL, NULL, NULL, NULL,
    NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '',
    '@', 'e', 'a', 'o', 'i', 'e', 'e', 'a', 'a', 'o', NULL, 'u', '\'', '', '', '',
    '', '', '', ':', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    '', 'b', 'g', 'd', 'h', 'v', 'z', 'kh', 't', 'y', 'k', 'k', 'l', 'm', 'm', 'n',
    'n', 's', '`', 'p', 'p', 'ts', 'ts', 'q', 'r', 'sh', 't', NULL, NULL, NULL, NULL, NULL,
    'V', 'oy', 'i', '\'', '"', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
