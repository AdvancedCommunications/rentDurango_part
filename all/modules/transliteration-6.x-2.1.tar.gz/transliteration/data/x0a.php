<?php
// $Id: x0a.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, NULL, 'N', NULL, NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', NULL, NULL, NULL, NULL, 'ee',
    'ai', NULL, NULL, 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
    'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bb', 'm', 'y',
    'r', NULL, 'l', 'll', NULL, 'v', 'sh', NULL, 's', 'h', NULL, NULL, '\'', NULL, 'aa', 'i',
    'ii', 'u', 'uu', NULL, NULL, NULL, NULL, 'ee', 'ai', NULL, NULL, 'oo', 'au', '', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'khh', 'ghh', 'z', 'rr', NULL, 'f', NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'N', 'H', '', '', 'G.E.O.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, 'N', 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', NULL, 'eN', NULL, 'e',
    'ai', 'oN', NULL, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
    'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bh', 'm', 'ya',
    'r', NULL, 'l', 'll', NULL, 'v', 'sh', 'ss', 's', 'h', NULL, NULL, '\'', '\'', 'aa', 'i',
    'ii', 'u', 'uu', 'R', 'RR', 'eN', NULL, 'e', 'ai', 'oN', NULL, 'o', 'au', '', NULL, NULL,
    'AUM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    'RR', NULL, NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
