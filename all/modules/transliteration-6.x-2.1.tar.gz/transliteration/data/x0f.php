<?php
// $Id: x0f.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array('AUM', '', '', '', '', '', '', '', ' // ', ' * ', '', '-', ' / ', ' / ', ' // ', ' -/ ',
    ' +/ ', ' X/ ', ' /XX/ ', ' /X/ ', ',', '', '', '', '', '', '', '', '', '', '', '',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.5', '1.5', '2.5', '3.5', '4.5', '5.5',
    '6.5', '7.5', '8.5', '-.5', '+', '*', '^', '_', '', '~', NULL, ']', '[[', ']]', '', '',
    'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', NULL, 'ny', 'tt', 'tth', 'dd', 'ddh', 'nn', 't',
    'th', 'd', 'dh', 'n', 'p', 'ph', 'b', 'bh', 'm', 'ts', 'tsh', 'dz', 'dzh', 'w', 'zh', 'z',
    '\'', 'y', 'r', 'l', 'sh', 'ssh', 's', 'h', 'a', 'kss', 'r', NULL, NULL, NULL, NULL, NULL,
    NULL, 'aa', 'i', 'ii', 'u', 'uu', 'R', 'RR', 'L', 'LL', 'e', 'ee', 'o', 'oo', 'M', 'H',
    'i', 'ii', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL,
    'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', NULL, 'ny', 'tt', 'tth', 'dd', 'ddh', 'nn', 't',
    'th', 'd', 'dh', 'n', 'p', 'ph', 'b', 'bh', 'm', 'ts', 'tsh', 'dz', 'dzh', 'w', 'zh', 'z',
    '\'', 'y', 'r', 'l', 'sh', 'ss', 's', 'h', 'a', 'kss', 'w', 'y', 'r', NULL, 'X', ' :X: ',
    ' /O/ ', ' /o/ ', ' \\o\\ ', ' (O) ', '', '', '', '', '', '', '', '', '', NULL, NULL, '',
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
