<?php
// $Id: x0e.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, 'k', 'kh', 'kh', 'kh', 'kh', 'kh', 'ng', 'cch', 'ch', 'ch', 'ch', 'ch', 'y', 'd', 't',
    'th', 'th', 'th', 'n', 'd', 't', 'th', 'th', 'th', 'n', 'b', 'p', 'ph', 'f', 'ph', 'f',
    'ph', 'm', 'y', 'r', 'R', 'l', 'L', 'w', 's', 's', 's', 'h', 'l', '`', 'h', '~',
    'a', 'a', 'aa', 'am', 'i', 'ii', 'ue', 'uue', 'u', 'uu', '\'', NULL, NULL, NULL, NULL, 'Bh.',
    'e', 'ae', 'o', 'ai', 'ai', 'ao', '+', '', '', '', '', '', '', 'M', '', ' * ',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' // ', ' /// ', NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, 'k', 'kh', NULL, 'kh', NULL, NULL, 'ng', 'ch', NULL, 's', NULL, NULL, 'ny', NULL, NULL,
    NULL, NULL, NULL, NULL, 'd', 'h', 'th', 'th', NULL, 'n', 'b', 'p', 'ph', 'f', 'ph', 'f',
    NULL, 'm', 'y', 'r', NULL, 'l', NULL, 'w', NULL, NULL, 's', 'h', NULL, '`', '', '~',
    'a', '', 'aa', 'am', 'i', 'ii', 'y', 'yy', 'u', 'uu', NULL, 'o', 'l', 'ny', NULL, NULL,
    'e', 'ei', 'o', 'ay', 'ai', NULL, '+', NULL, '', '', '', '', '', 'M', NULL, NULL,
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', NULL, NULL, 'hn', 'hm', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
