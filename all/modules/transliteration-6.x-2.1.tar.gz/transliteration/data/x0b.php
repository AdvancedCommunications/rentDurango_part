<?php
// $Id: x0b.php,v 1.1.8.1 2008/06/12 20:34:31 smk Exp $

return array(
  'en' => array(NULL, 'N', 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', NULL, NULL, 'e',
    'ai', NULL, NULL, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
    'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bh', 'm', 'y',
    'r', NULL, 'l', 'll', NULL, '', 'sh', 'ss', 's', 'h', NULL, NULL, '\'', '\'', 'aa', 'i',
    'ii', 'u', 'uu', 'R', NULL, NULL, NULL, 'e', 'ai', NULL, NULL, 'o', 'au', '', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, '+', '+', NULL, NULL, NULL, NULL, 'rr', 'rh', NULL, 'yy',
    'RR', 'LL', NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', NULL, NULL, NULL, 'e', 'ee',
    'ai', NULL, 'o', 'oo', 'au', 'k', NULL, NULL, NULL, 'ng', 'c', NULL, 'j', NULL, 'ny', 'tt',
    NULL, NULL, NULL, 'nn', 't', NULL, NULL, NULL, 'n', 'nnn', 'p', NULL, NULL, NULL, 'm', 'y',
    'r', 'rr', 'l', 'll', 'lll', 'v', NULL, 'ss', 's', 'h', NULL, NULL, NULL, NULL, 'aa', 'i',
    'ii', 'u', 'uu', NULL, NULL, NULL, 'e', 'ee', 'ai', NULL, 'o', 'oo', 'au', '', NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, '+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    '+10+', '+100+', '+1000+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
);
