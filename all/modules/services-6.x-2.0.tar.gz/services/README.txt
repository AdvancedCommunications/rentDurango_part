// $Id: README.txt,v 1.8.2.1 2008/09/06 04:13:07 marcingy Exp $

Goals
==============
- Create a unified Drupal API for web services to be exposed in a variety of 
  different server formats.  
- Provide a service browser to be able to test methods.
- Allow distribution of API keys for developer access.

Documentation
==============
http://drupal.org/node/109782