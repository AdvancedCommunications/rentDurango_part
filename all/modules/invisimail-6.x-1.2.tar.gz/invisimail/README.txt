REQUIREMENTS
------------

Drupal 5

INSTALL
-------

1. Copy the invisimail.module file to your Drupal modules directory (e.g. sites/default/modules or sites/all/modules) as appropriate
2. Activate the module at Administer -> Site building -> Modules
3. Activate the filter at Administer -> Site configuration -> Input formats
   and click configure for the input format where you want to add the invisimail filter
4. Optionally configure the filter settings by clicking the configure
   tab on the input format screen where the "Encode email addresses" box is checked