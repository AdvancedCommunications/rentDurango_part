  <div class="box">
    <h2 class="title"><?php print $title; ?></h2>
    <div class="content"><?php print $content; ?></div>
 </div>

